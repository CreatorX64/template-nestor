# License Agreement

Upon downloading and/or using web templates listed on HTMLWOW website and on other template markets, you agree to this license. The terms are very simple. If you have any questions regarding your usage permissions of any template that you buy, please feel free to email me at: CreatorX64@gmail.com

## Upon download, you're allowed to:

- Use the templates for any personal and/or commercial project.
- Edit/remix the templates in any shape or form to fit it for your brand/project.
- Give no attribution whatsoever to the creator of the template and/or to HTMLWOW.

## You're not allowed to:

- Redistribute/resell the templates in any paid forms, in any platform.
- Claim authorship of a template in it's recognizable/base form without any modifications.
